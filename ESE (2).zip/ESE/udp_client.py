import socket

# Client setup
HOST = '127.0.0.1'  # Server address
PORT = 65432  # Server port

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

print("Connected to the UDP server.")

while True:
    command = input("Enter command (LIST, READ <filename>, WRITE <filename> <content>, DELETE <filename>, EXIT): ")
    if command == "EXIT":
        break

    client_socket.sendto(command.encode(), (HOST, PORT))  # Send command to server

    response, _ = client_socket.recvfrom(1024)  # Receive response from server
    print("Response from server:", response.decode())

client_socket.close()
print("Disconnected from the server.")
