import socket
import os

# Server setup
HOST = '127.0.0.1'  # Localhost
PORT = 65432  # Port to listen on

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind((HOST, PORT))

print(f"UDP Server started on {HOST}:{PORT}. Waiting for messages...")


def list_files():
    files = os.listdir('.')
    return '\n'.join(files)


def read_file(filename):
    try:
        with open(filename, 'r') as file:
            return file.read()
    except FileNotFoundError:
        return "File not found."


def write_file(filename, content):
    with open(filename, 'w') as file:
        file.write(content)
    return "File written successfully."


def delete_file(filename):
    try:
        os.remove(filename)
        return "File deleted successfully."
    except FileNotFoundError:
        return "File not found."


while True:
    data, addr = server_socket.recvfrom(1024)  # Buffer size is 1024 bytes
    command = data.decode()

    print(f"Received command from {addr}: {command}")

    response = ""
    command_parts = command.split()

    if command_parts[0] == "LIST":
        response = list_files()
    elif command_parts[0] == "READ" and len(command_parts) > 1:
        response = read_file(command_parts[1])
    elif command_parts[0] == "WRITE" and len(command_parts) > 2:
        filename = command_parts[1]
        content = ' '.join(command_parts[2:])
        response = write_file(filename, content)
    elif command_parts[0] == "DELETE" and len(command_parts) > 1:
        response = delete_file(command_parts[1])
    else:
        response = "Invalid command."

    server_socket.sendto(response.encode(), addr)  # Send response back to the client
