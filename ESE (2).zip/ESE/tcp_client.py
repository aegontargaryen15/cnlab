import socket

# Server host and port
HOST = '127.0.0.1'  # Localhost
PORT = 65432  # Port to connect to

# Client setup
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((HOST, PORT))

print("Connected to the server.")

# Client operation loop
while True:
    command = input("Enter command (LIST, READ <filename>, WRITE <filename> <content>, DELETE <filename>, EXIT): ")
    if command == "EXIT":
        break

    client_socket.sendall(command.encode())
    response = client_socket.recv(1024).decode()
    print("Response from server:", response)

client_socket.close()
print("Disconnected from the server.")
