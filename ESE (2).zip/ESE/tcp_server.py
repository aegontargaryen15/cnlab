import socket
import os

# Server host and port
HOST = '127.0.0.1'  # Localhost
PORT = 65432  # Port to listen on

# Server setup
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen()

print(f"Server started on {HOST}:{PORT}. Waiting for connections...")


# Helper functions for file operations
def list_files():
    files = os.listdir('.')
    return '\n'.join(files)


def read_file(filename):
    try:
        with open(filename, 'r') as file:
            return file.read()
    except FileNotFoundError:
        return "File not found."


def write_file(filename, content):
    with open(filename, 'w') as file:
        file.write(content)
    return "File written successfully."


def delete_file(filename):
    try:
        os.remove(filename)
        return "File deleted successfully."
    except FileNotFoundError:
        return "File not found."


# Client handler function
def handle_client(client_socket):
    while True:
        data = client_socket.recv(1024).decode()
        if not data:
            break

        command, *args = data.split()

        if command == "LIST":
            response = list_files()
        elif command == "READ" and args:
            response = read_file(args[0])
        elif command == "WRITE" and len(args) > 1:
            filename = args[0]
            content = ' '.join(args[1:])
            response = write_file(filename, content)
        elif command == "DELETE" and args:
            response = delete_file(args[0])
        else:
            response = "Invalid command."

        client_socket.sendall(response.encode())
    client_socket.close()


# Main loop to accept clients
while True:
    client_socket, addr = server_socket.accept()
    print(f"Connected to {addr}")
    handle_client(client_socket)
