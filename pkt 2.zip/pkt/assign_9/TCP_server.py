import socket

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 65432

# Create TCP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((SERVER_HOST, SERVER_PORT))
server_socket.listen(1)

print("************************************")
print("\tTCP SERVER TERMINAL")
print("************************************")
print("Waiting for connection...")

conn, addr = server_socket.accept()
print(f"Connected to socket\nConnection accepted successfully")

while True:
    data = conn.recv(1024).decode()
    if data == "exit":
        print("Client disconnected.")
        break

    values = data.split(',')
    if len(values) == 2:
        num1, num2 = map(float, values)
        print(f"First Value is {num1}")
        print(f"Second Value is {num2}")
        addition = num1 + num2
        print(f"Addition is {addition}")
        conn.sendall(str(addition).encode())

conn.close()
