import socket

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 6666

# Create UDP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind((SERVER_HOST, SERVER_PORT))

print("***********************************")
print("\tUDP SERVER TERMINAL")
print("***********************************")
print(f"UDP Server waiting for client on port no {SERVER_PORT}")

while True:
    # Receive data from client
    data, client_address = server_socket.recvfrom(1024)
    values = data.decode().split(',')
    if len(values) == 2:
        num1, num2 = map(float, values)
        print(f"First value is {num1}")
        print(f"Second value is {num2}")
        addition = num1 + num2
        print(f"Addition is {addition}")
        # Send result back to client
        server_socket.sendto(str(addition).encode(), client_address)
